
api_id = 123456  # Replace with your own API ID from my.telegram.org
api_hash = "your_api_hash_here"
bot_token = "7307402708:AAEgbvviLJdxjsSwW0eULdfuvR5gxZuwL2c"
