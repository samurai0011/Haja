
# CDS Journey Telegram Bot - FINAL

## Features
- Email + OTP login or direct token
- Extracts all Zoom links from your batches
- Sends a .txt file with all video links

## How to Use
1. Set your api_id and api_hash in config.py
2. Run `pip install pyrogram tgcrypto aiohttp`
3. Run with: `python main.py`
4. Interact on Telegram to login and extract

Enjoy!
